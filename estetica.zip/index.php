<?php
header('Location: ./public/');
