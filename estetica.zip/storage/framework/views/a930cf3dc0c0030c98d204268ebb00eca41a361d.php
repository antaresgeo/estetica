<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('user.index')); ?>">Usuarios</a>
    </li>
    <li class="breadcrumb-item active">Nuevo Usuario</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span>Nuevo Usuario</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => 'user.store', 'method' => 'POST']); ?>

<div class="form-group">
    <?php echo Form::label('name', 'Nombre'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('email', 'Correo electrónico'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'require', 'placeholder' => 'ejemplo@gmail.com']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('password', 'Contraseña'); ?>

    <?php echo Form::password('password', ['class' => 'form-control', 'require' , 'placeholder' => '****']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('type', 'Tipo de Usuario'); ?>

    <?php echo Form::select('type', ['admin' => 'Administrador', 'regular' => 'Regular'], null, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Cancelar</a>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>