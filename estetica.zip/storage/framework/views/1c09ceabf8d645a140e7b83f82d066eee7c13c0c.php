<?php $__env->startSection('header'); ?>
<i class="fa fa-table" aria-hidden="true"></i>
<span><?php echo $__env->yieldContent('theader'); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="table-responsive">
    <table class="table table-bordered" width="100%" cellspacing="0" id="datatable">
        <thead class="thead-light">
            <?php echo $__env->yieldContent('thead'); ?>
        </thead>
        <tbody>
            <?php echo $__env->yieldContent('tbody'); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>