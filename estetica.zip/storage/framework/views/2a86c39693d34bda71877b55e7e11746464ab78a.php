<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('theader', 'Tabla de Clientes'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Clientes</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pre-card'); ?>
<div class="d-flex">
    <div class="mr-auto p-2"></div>
    <a href="<?php echo e(route('cliente.create')); ?>" class="btn btn-primary p-2">Nuevo Cliente</a>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('thead'); ?>
<tr>
    
    <th>Nombre</th>
    <th>Telefono</th>
    <th>DNI</th>
    <th>Correo electrónico</th>
    
    <th>Fecha de nacimiento</th>
    
    <th>Acción</th>
</tr>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#datatable').DataTable({
        processing: true,
        serverSide: true,
        language: {
            "url": "<?php echo e(asset('js/Spanish.json')); ?>"
        },
        ajax: '<?php echo route('cliente.list'); ?>',
        columns: [
            { data: 'nombre', name: 'nombre' },
            { data: 'telefono', name: 'telefono' },
            { data: 'identificacion', name: 'identificacion' },
            { data: 'email', name: 'email'},
            // { data: 'localidad', name: 'localidad'},
            { data: 'fecha_nacimiento', name: 'fecha_nacimiento'},
            // { data: 'ocupacion', name: 'ocupacion'},
            { data: 'id', name: 'id', searchable: false, orderable: false, render: function ( data, type, row, meta ) {
                var edit = '<?php echo e(route('cliente.edit', ':id')); ?>'.replace(':id', data);
                var destroy = '<?php echo e(route('cliente.destroy', ':id')); ?>'.replace(':id', data);
                return '<a href="'+ edit +'" class="btn btn-warning" style="margin-right: 7px;"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="'+destroy+'" class="btn btn-danger" style="margin-right: 7px;"><i class="fa fa-trash" aria-hidden="true"></i></a>'
            }}
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>





<?php echo $__env->make('layouts.new.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>