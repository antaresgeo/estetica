<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('tratamiento.index')); ?>">Tratamientos</a>
    </li>
    <li class="breadcrumb-item active">Nueva Tratamiento</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span>Nuevo Tratamiento</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => 'tratamiento.store', 'method' => 'POST']); ?>

<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('cantidad', 'Cantidad de sesiones'); ?>

    <?php echo Form::number('cantidad', null, ['class' => 'form-control', 'require', 'placeholder' => 'Cantidad de sesiones']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('precio', 'Precio'); ?>

    <?php echo Form::number('precio', null, ['class' => 'form-control', 'require', 'placeholder' => 'Precio']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>