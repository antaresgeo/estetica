<?php $__env->startSection('title', 'Editar usuario '. $user->name); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('user.index')); ?>">Usuarios</a>
    </li>
    <li class="breadcrumb-item active"><?php echo e($user->name); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span> <?php echo e($user->name); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => ['user.update', $user], 'method' => 'PUT']); ?>

<div class="form-group">
    <?php echo Form::label('name', 'Nombre'); ?>

    <?php echo Form::text('name', $user->name, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('email', 'Correo electrónico'); ?>

    <?php echo Form::email('email', $user->email, ['class' => 'form-control', 'require', 'placeholder' => 'ejemplo@gmail.com']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('type', 'Tipo de Usuario'); ?>

    <?php echo Form::select('type', ['admin' => 'Administrador', 'regular' => 'Regular'], $user->type, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Editar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Cancelar</a>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
Ultima edicion <?php echo e($user->updated_at); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>