<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('reserva.index')); ?>">Reservas</a>
    </li>
    <li class="breadcrumb-item active">Nueva Reserva</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span>Nueva Reserva</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => 'reserva.store', 'method' => 'POST']); ?>

<div class="form-group">
    <?php echo Form::label('hora', 'Hora'); ?>

    <?php echo Form::date('hora', null, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('sucursal_id', 'Sucursal'); ?>

    <?php echo Form::select('sucursal_id', $sucursales, null, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('user_id', 'Profecional'); ?>

    <?php echo Form::select('user_id', $profecionales, null, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('cliente_id', 'Profecional'); ?>

    <?php echo Form::select('cliente_id', $profecionales, null, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('estado', 'Estado'); ?>

    <?php echo Form::select('estado', ['pendiente' => 'Pendiente', 'realizada' => 'Realizada', 'cancelada' => 'Cancelada'], null, ['class' => 'form-control', 'placeholder' => '----' ]); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>