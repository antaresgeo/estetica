<?php $__env->startSection('title', 'Sucursales'); ?>

<?php $__env->startSection('theader', 'Tabla de Sucursales'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Sucursales</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pre-card'); ?>
<div class="d-flex">
    <div class="mr-auto p-2"></div>
    <a href="<?php echo e(route('sucursal.create')); ?>" class="btn btn-primary p-2">Nueva Sucursal</a>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('thead'); ?>
<tr>
    
    <th>Nombre</th>
    <th>Acción</th>
</tr>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#datatable').DataTable({
        processing: true,
        serverSide: true,
        language: {
            "url": "<?php echo e(asset('js/Spanish.json')); ?>"
        },
        ajax: '<?php echo route('sucursal.list'); ?>',
        columns: [
            { data: 'nombre', name: 'nombre' },
            { data: 'id', name: 'id', searchable: false, orderable: false, render: function ( data, type, row, meta ) {
                var edit = '<?php echo e(route('sucursal.edit', ':id')); ?>'.replace(':id', data);
                var destroy = '<?php echo e(route('sucursal.destroy', ':id')); ?>'.replace(':id', data);
                return '<a href="'+ edit +'" class="btn btn-warning" style="margin-right: 7px;"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="'+destroy+'" class="btn btn-danger" style="margin-right: 7px;"><i class="fa fa-trash" aria-hidden="true"></i></a>'
            }}
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>





<?php echo $__env->make('layouts.new.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>