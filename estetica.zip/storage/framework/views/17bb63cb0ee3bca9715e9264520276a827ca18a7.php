<?php $__env->startSection('title', 'Nuevo Cliente '); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('cliente.index')); ?>">Clientes</a>
    </li>
    <li class="breadcrumb-item active">Nuevo Cliente</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span>Nuevo Cliente</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => 'cliente.store', 'method' => 'POST']); ?>

<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('telefono', 'Numero Telefonico'); ?>

    <?php echo Form::text('telefono', null, ['class' => 'form-control', 'require', 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('identificacion', 'Identificacion'); ?>

    <?php echo Form::text('identificacion', null,['class' => 'form-control', 'require' , 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>