<?php $__env->startSection('title', 'Editar tratatamiento '. $tratamiento->nombre); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('tratamiento.index')); ?>">Tratamientos</a>
    </li>
    <li class="breadcrumb-item active"><?php echo e($tratamiento->nombre); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span> <?php echo e($tratamiento->nombre); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => ['tratamiento.update', $tratamiento], 'method' => 'PUT']); ?>

<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre'); ?>

    <?php echo Form::text('nombre', $tratamiento->nombre, ['class' => 'form-control', 'required', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('cantidad', 'Cantidad de sesiones'); ?>

    <?php echo Form::number('cantidad', $tratamiento->cantidad, ['class' => 'form-control', 'required', 'placeholder' => 'Cantidad de sesiones', 'min' => 0]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('precio', 'Precio'); ?>

    <?php echo Form::number('precio', $tratamiento->precio, ['class' => 'form-control', 'required', 'placeholder' => 'Precio', 'min'=> 0]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('duracion', 'Duración (minutos)'); ?>

    <?php echo Form::number('duracion', $tratamiento->duracion, ['class' => 'form-control', 'required', 'placeholder' => 'Duración en minutos', 'min' => 0]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('rotativo', 'Rotativo'); ?>

    <?php echo Form::checkbox('rotativo',  1, $tratamiento->rotativo); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Editar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('tratamiento.index')); ?>" class="btn btn-primary">Cancelar</a>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
Ultima edicion <?php echo e($tratamiento->updated_at); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>