<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldContent('pre-card'); ?>
<div class="card mb-3">
    <div class="card-header">
        <?php echo $__env->yieldContent('header'); ?>
    </div>
    <div class="card-body">
        <?php echo $__env->yieldContent('body'); ?>
    </div>
    <div class="card-footer small">
        <?php echo $__env->yieldContent('footer'); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>