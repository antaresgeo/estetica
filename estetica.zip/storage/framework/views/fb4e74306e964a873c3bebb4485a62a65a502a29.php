<?php $__env->startSection('title', 'Editar Cliente '. $cliente->nombre); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('cliente.index')); ?>">Clientes</a>
    </li>
    <li class="breadcrumb-item active"><?php echo e($cliente->nombre); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span> <?php echo e($cliente->nombre); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => ['cliente.update', $cliente], 'method' => 'PUT']); ?>

<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre'); ?>

    <?php echo Form::text('nombre', $cliente->nombre, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('telefono', 'Número Telefónico'); ?>

    <?php echo Form::text('telefono', $cliente->telefono, ['class' => 'form-control', 'require', 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('identificacion', 'DNI'); ?>

    <?php echo Form::text('identificacion', $cliente->identificacion,  ['class' => 'form-control', 'require' , 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('email', 'Correo electrónico'); ?>

    <?php echo Form::email('email', $cliente->email, ['class' => 'form-control', 'require', 'placeholder' => 'ejemplo@gmail.com']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('localidad', 'Localidad'); ?>

    <?php echo Form::text('localidad', $cliente->localidad,['class' => 'form-control', 'require' , 'placeholder' => 'localidad']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('facha_nacimiento', 'Fecha de nacimiento'); ?>

    <div class="input-group date" id="datetimepicker1" data-target-input="nearest">
        <span class="input-group-addon" data-target="#datetimepicker1" data-toggle="datetimepicker">
            <span class="fa fa-calendar"></span>
        </span>
        <?php echo Form::text('facha_nacimiento', $cliente->facha_nacimiento,['class' => 'form-control  datetimepicker-input', 'require' , 'data-target' => '#datetimepicker1']); ?>

    </div>
</div>
<div class="form-group">
    <?php echo Form::label('ocupacion', 'Ocupación'); ?>

    <?php echo Form::text('ocupacion', $cliente->ocupacion,['class' => 'form-control', 'require' , 'placeholder' => 'ocupación']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Editar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-primary">Cancelar</a>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
Ultima edicion <?php echo e($cliente->updated_at); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#datetimepicker1').datetimepicker({
        format:'YYYY-MM-DD',
        icons: {
            time: "fa fa-clock-o",
            date: "fa fa-calendar",
            up: "fa fa-arrow-up",
            down: "fa fa-arrow-down"
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>