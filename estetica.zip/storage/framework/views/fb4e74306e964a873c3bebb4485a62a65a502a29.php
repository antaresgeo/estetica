<?php $__env->startSection('title', 'Editar Cliente '. $cliente->nombre); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('cliente.index')); ?>">Clientes</a>
    </li>
    <li class="breadcrumb-item active"><?php echo e($cliente->nombre); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<i class="fa fa-pencil" aria-hidden="true"></i>
<span> <?php echo e($cliente->nombre); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open(['route' => ['cliente.update', $cliente], 'method' => 'PUT']); ?>

<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre'); ?>

    <?php echo Form::text('nombre', $cliente->nombre, ['class' => 'form-control', 'require', 'placeholder' => 'Nombre']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('telefono', 'Numero Telefonico'); ?>

    <?php echo Form::text('telefono', $cliente->telefono, ['class' => 'form-control', 'require', 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('identificacion', 'Identificacion'); ?>

    <?php echo Form::text('identificacion', $cliente->identificacion,  ['class' => 'form-control', 'require' , 'placeholder' => '111xxx']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Editar', ['class' => 'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
Ultima edicion <?php echo e($cliente->updated_at); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.card', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>